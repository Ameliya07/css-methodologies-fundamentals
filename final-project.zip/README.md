# Fundamentals of Web Development — Final Project

A responsive "System Requirements" page built with semantic HTML, BEM,
and Sass, adapted for both desktop and mobile.

## Getting started

```bash
npm install
npm run compile   # scss -> src/dist/style.css
npm run prod       # full pipeline: compile + autoprefix + purge + minify
npm run lint        # stylelint --fix on all .scss
npm run format       # prettier --write on scss/html/js
```

Open `src/index.html` directly in a browser (it links `./dist/style.css`,
so run `npm run compile` or `npm run prod` at least once first).

## Structure

```
src/
  index.html
  assets/
    logo.png          placeholder logo — swap for the real design asset
    stars.png          placeholder illustration — swap for the real design asset
    fonts/               drop a real font file here if the design calls for one
  scripts/
    menu.js               burger-menu open/close toggle
  styles/
    style.scss             desktop entry point (required filename/location)
    mobile.scss             responsive overrides (required filename/location)
    kit/
      _variables.scss        colors, type scale, spacing, breakpoints
      _mixins.scss             container, flex helpers, hover-underline, button, etc.
    _header.scss, _menu.scss, _text-section.scss,
    _video-section.scss, _cta.scss, _footer.scss   one partial per block
  dist/                       generated — style.css + style.min.css (not committed until built)
```

## What's implemented

- Semantic markup: `<header>`, `<nav>`, `<main>`, `<section>`, `<article>`,
  `<footer>`; desktop nav via `<nav><ul><li><a>`; heading split with `<br>`;
  bottom CTA button with the `▶` (`&#9654;`) symbol; `mailto:` link in the
  footer.
- BEM naming throughout (`block__element--modifier`).
- Grid/Flexbox layout; hover underline on nav links (desktop and mobile).
- Sass: variables + mixins in `styles/kit`, one partial per block, nested
  selectors, imported from `style.scss`.
- Mobile: burger menu (768px breakpoint) that toggles via `menu.js`, and a
  fully responsive layout down to a 600px breakpoint, in `mobile.scss`.
- Animations: infinite logo rotate + zoom in the header; rotate/scale
  transform on the play button and the CTA button on hover.
- Build pipeline: `sass` for compiling, `postcss` + `autoprefixer` +
  `@fullhuman/postcss-purgecss` + `cssnano` for the `prod` script, `stylelint`
  (`stylelint-config-standard-scss`) for linting, `prettier` for formatting.
  `prod` writes both `src/dist/style.css` (compiled, prefixed, purged) and
  `src/dist/style.min.css` (minified).

## Known gap — design fidelity

The Figma link in the task couldn't be pulled into exact colors, spacing,
fonts, or images for this build, so `logo.png` and `stars.png` are simple
generated placeholders and the color palette in `kit/_variables.scss` is a
reasonable default rather than a pixel match. To finish matching the design:

1. Export the real logo/illustration assets from Figma into `src/assets/`.
2. Copy the real colors, font, and spacing values into `kit/_variables.scss`.
3. Re-run `npm run prod` and compare against the Figma frames at both the
   desktop and mobile breakpoints.
