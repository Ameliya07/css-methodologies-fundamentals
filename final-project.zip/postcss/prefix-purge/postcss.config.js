module.exports = {
  plugins: [
    require('autoprefixer'),
    require('@fullhuman/postcss-purgecss')({
      content: ['./src/**/*.html', './src/scripts/**/*.js'],
      defaultExtractor: (content) => content.match(/[\w-/:%.]+(?<!:)/g) || [],
      safelist: ['menu--open', 'burger--open']
    })
  ]
};
