(function () {
  const burger = document.querySelector('.burger');
  const menu = document.querySelector('.menu');

  if (!burger || !menu) {
    return;
  }

  burger.addEventListener('click', function () {
    const isOpen = menu.classList.toggle('menu--open');
    burger.classList.toggle('burger--open', isOpen);
    burger.setAttribute('aria-expanded', String(isOpen));
    burger.setAttribute('aria-label', isOpen ? 'Закрыть меню' : 'Открыть меню');
  });

  menu.querySelectorAll('.menu__link').forEach(function (link) {
    link.addEventListener('click', function () {
      menu.classList.remove('menu--open');
      burger.classList.remove('burger--open');
      burger.setAttribute('aria-expanded', 'false');
      burger.setAttribute('aria-label', 'Открыть меню');
    });
  });
})();
